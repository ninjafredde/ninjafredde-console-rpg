// src/render.rs

use std::io::{self, Stdout};
use ratatui::{
    backend::CrosstermBackend,
    Terminal,
    layout::{Layout, Constraint, Direction},
    widgets::{Paragraph, Block, Borders},
    style::{Style, Color, Stylize},
    text::{Text, Line,Span},
};

use crate::game::{Game, GamePhase};
use crate::world::{get_interaction_prompt}; // should eventuelly not have to be called here

// main calls this from the game loop
pub fn render_game(
    terminal: &mut Terminal<CrosstermBackend<std::io::Stdout>>,
    game: &mut Game,
) -> Result<(), Box<dyn std::error::Error>> {
    match game.phase {
        GamePhase::PlayingWorld => render_world(terminal, game),
        GamePhase::Menu => render_menu(terminal, game),
        GamePhase::GameOver => render_game_over(terminal, game),
    }
}
// this should not need to be mutable
// all the updates to world should happen in the world module
// and be passed in as immutable

fn render_world(
    terminal: &mut Terminal<CrosstermBackend<std::io::Stdout>>,
    game: Game,  // <-- now mutable!
) -> Result<(), Box<dyn std::error::Error>> {
    terminal.draw(|f| {
        //crate::world::update_visibility(&mut game.world, game.player_pos, game.view_radius);


        let size = f.size();
        let chunks = Layout::default()
            .direction(Direction::Vertical)
            .margin(1)
            .constraints([
                Constraint::Percentage(70),
                Constraint::Percentage(30),
            ])
            .split(size);

        let bottom_chunks = Layout::default()
            .direction(Direction::Vertical)
            .constraints([
                Constraint::Min(1),
                Constraint::Min(1),
            ])
            .split(chunks[1]);

        let map_widget = render_tile_map(
            game.world,
            game.player_pos,
            game.view_radius,
            "Map",
        );
        f.render_widget(map_widget, chunks[0]);

        let stats = Paragraph::new(Span::from(game.player.stats()));
        f.render_widget(stats, bottom_chunks[0]);

        if let Some(prompt) =
            get_interaction_prompt(game.world.get_tile(game.player_pos.0, game.player_pos.1))
        {
            let action = Paragraph::new(Span::from(prompt));
            f.render_widget(action, bottom_chunks[1]);
        }
    })?;
    Ok(())
}

//rendering should happen in render.rs
pub fn render_tile_map(
    map: World,
    player_pos: (usize, usize),
    view_radius: i32,
    title: &str,
) -> Paragraph<'static> {
    let mut lines = Vec::new();
    let (px, py) = (player_pos.0 as i32, player_pos.1 as i32);
    //println!("Rendering map centered on: {:?}", player_pos);

    for dy in -view_radius..=view_radius {
        let mut row = Vec::new();
        for dx in -view_radius..=view_radius {
            let x = px + dx;
            let y = py + dy;

            let (wrapped_x, wrapped_y, in_bounds) = if map.wraparound {
                let w = map.width() as i32;
                let h = map.height() as i32;
                (
                    (x.rem_euclid(w)) as usize,
                    (y.rem_euclid(h)) as usize,
                    true,
                )
            } else if x < 0 || y < 0 || x >= map.width() as i32 || y >= map.height() as i32 {
                (0, 0, false)
            } else {
                (x as usize, y as usize, true)
            };

            if !in_bounds {
                row.push(Span::raw("  "));
                continue;
            }

            let tile = &mut map.tiles[wrapped_y][wrapped_x];
            let dist = dx.abs().max(dy.abs());

            let dist = dx.abs().max(dy.abs());
            let (symbol, color) = tile.appearance();

            let visibility_radius = view_radius;
            let fog_display_radius = view_radius / 4;

            // Update visibility
            if dist <= visibility_radius {
                tile.seen = true;
            }

            let span = if !tile.seen {
                // 1. Never seen — hide it
                Span::raw("  ")
            } else if dx == 0 && dy == 0 {
                // 2. Player tile
                Span::styled("@ ", Style::default().fg(Color::White).bold())
            } else if dist <= fog_display_radius {
                // 3. Within current view radius — full color
                Span::styled(format!("{} ", symbol), Style::default().fg(color))
            } else {
                // 4. Seen before, outside current view — dimmed
                Span::styled(format!("{} ", symbol), Style::default().fg(color).dim())
            };



            row.push(span);
        }
        lines.push(Line::from(row));
    }

    let map_title = format!(
        "{} ({}, {}) - {:?}",
        title,
        player_pos.0,
        player_pos.1,
        map.get_tile(player_pos.0, player_pos.1).terrain
    );

    Paragraph::new(Text::from(lines))
        .block(Block::default().borders(Borders::ALL).title(Span::from(map_title)))
}


fn render_menu(
    _terminal: &mut Terminal<CrosstermBackend<std::io::Stdout>>,
    _game: &crate::game::Game,
) -> Result<(), Box<dyn std::error::Error>> {
    Ok(())
}

fn render_game_over(
    _terminal: &mut Terminal<CrosstermBackend<std::io::Stdout>>,
    _game: &crate::game::Game,
) -> Result<(), Box<dyn std::error::Error>> {
    Ok(())
}



pub type GameTerminal = Terminal<CrosstermBackend<Stdout>>;

// functions to handle terminal initialization and shutdown
pub fn init_terminal() -> io::Result<GameTerminal> {
    use crossterm::{execute, terminal::{EnterAlternateScreen, enable_raw_mode}};

    enable_raw_mode()?;
    let mut stdout = io::stdout();
    execute!(stdout, EnterAlternateScreen)?;
    let backend = CrosstermBackend::new(stdout);
    Terminal::new(backend)
}

pub fn shutdown_terminal(terminal: &mut GameTerminal) -> io::Result<()> {
    use crossterm::{execute, terminal::{LeaveAlternateScreen, disable_raw_mode}};
    disable_raw_mode()?;
    execute!(terminal.backend_mut(), LeaveAlternateScreen)?;
    Ok(())
}
